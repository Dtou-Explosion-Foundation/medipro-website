/**
 * JPanelを格納する.
 */
package medipro.gui.panel;
