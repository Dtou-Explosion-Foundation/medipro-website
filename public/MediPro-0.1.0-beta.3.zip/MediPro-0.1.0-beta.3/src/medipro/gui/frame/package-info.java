/**
 * JFrameを格納する.
 */
package medipro.gui.frame;
