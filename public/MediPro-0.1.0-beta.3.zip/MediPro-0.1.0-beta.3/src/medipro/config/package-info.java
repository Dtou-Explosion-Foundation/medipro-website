/**
 * コンフィグに関するクラスを格納する.
 */
package medipro.config;
