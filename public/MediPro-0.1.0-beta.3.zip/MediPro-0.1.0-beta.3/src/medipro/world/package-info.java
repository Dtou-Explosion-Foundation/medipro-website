/**
 * ワールド関連のクラスを格納する.
 */
package medipro.world;
