/**
 * リザルトのGUIを提供する.
 */
package medipro.result;
