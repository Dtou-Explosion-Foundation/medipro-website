/**
 * タイトルのメニューのGUIを提供する.
 */
package medipro.titlemenu;
