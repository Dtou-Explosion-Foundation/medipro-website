/**
 * タイトルメニューの背景を提供する.
 */
package medipro.titlemenu.titlebackground;
