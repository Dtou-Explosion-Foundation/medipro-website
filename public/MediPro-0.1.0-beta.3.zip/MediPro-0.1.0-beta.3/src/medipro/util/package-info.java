/**
 * ユーティリティクラスを提供する.
 */
package medipro.util;
