/**
 * 異変に関するクラスを格納する.
 */
package medipro.anomaly;
