/**
 * プレイヤー関連のクラスを格納する.
 */
package medipro.object.player;
