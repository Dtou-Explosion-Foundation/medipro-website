/**
 * ゲームオブジェクトを提供する.
 */
package medipro.object;
