/**
 * 階段を実装するオブジェクトを提供する.
 */
package medipro.object.stage.stairs;
