/**
 * 背景を実装するオブジェクトを提供する.
 */
package medipro.object.stage.background;
