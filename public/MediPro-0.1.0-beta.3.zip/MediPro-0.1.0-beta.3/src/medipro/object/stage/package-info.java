/**
 * ステージを作るためのオブジェクトを提供する.
 */
package medipro.object.stage;
