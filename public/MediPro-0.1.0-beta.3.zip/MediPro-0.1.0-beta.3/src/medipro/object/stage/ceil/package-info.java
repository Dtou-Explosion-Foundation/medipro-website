/**
 * 天井を実装するオブジェクトを提供する.
 */
package medipro.object.stage.ceil;
