/**
 * ステージに配置するオブジェクトを提供する.
 */
package medipro.object.ornament;
