/**
 * テクスチャをベースにしたオブジェクトを提供する.
 */
package medipro.object.ornament.texture;
