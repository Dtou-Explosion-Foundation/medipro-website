/**
 * ゲームの管理を行うクラスを提供する.
 */
package medipro.object.manager.gamemanager;
