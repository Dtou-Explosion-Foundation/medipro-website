/**
 * 描画を行わず、他のオブジェクトの管理を目的とするクラスを提供する.
 */
package medipro.object.manager;
