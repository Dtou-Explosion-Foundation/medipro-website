/**
 * カメラの位置に関わらず画面上に表示されるオブジェクトを提供する.
 */
package medipro.object.overlay;
