/**
 * 画面の端を暗くする効果（ビネット）を実装するオブジェクトを提供する.
 */
package medipro.object.overlay.vignette;
