/**
 * 暗転を実装するオブジェクトを提供する.
 */
package medipro.object.overlay.blackfilter;
