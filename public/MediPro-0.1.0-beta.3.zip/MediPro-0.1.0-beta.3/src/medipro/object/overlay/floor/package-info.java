/**
 * 現在のfloorを画面上に表示するオブジェクトを提供する.
 */
package medipro.object.overlay.floor;
