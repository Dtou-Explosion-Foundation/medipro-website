/**
 * 基底クラスであるGameObject関連のクラスを格納する.
 */
package medipro.object.base.gameobject;
