/**
 * カメラ関連の基本クラスを格納する.
 */
package medipro.object.base.camera;
