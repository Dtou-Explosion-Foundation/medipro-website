/**
 * タイルを敷き詰めたグリッド状のオブジェクトを表すクラスを格納する.
 */
package medipro.object.base.gridobject;
