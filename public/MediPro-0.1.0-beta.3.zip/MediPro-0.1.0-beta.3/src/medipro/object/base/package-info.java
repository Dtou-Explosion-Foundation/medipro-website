/**
 * 基本的なオブジェクトを提供する.
 */
package medipro.object.base;
